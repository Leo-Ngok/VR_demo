
Thank you for using TEXDraw as part of your project.

For getting started, you can open example scenes to see which equations that you expect to work with TEXDraw.

Related links to TEXDraw:

Asset Store: https://assetstore.unity.com/packages/tools/gui/texdraw-51426
Documentation: https://willnode.gitlab.io/texdraw/
Landing Page: https://wellosoft.net/texdraw
Git Repository: https://gitlab.com/willnode/texdraw/
Request Git Access: https://wellosoft.net/grants/

If you need something to ask, you can reach us here:

Chat (for urgent or quick question): https://t.me/WIIIN0DE
Email (for private long conversation): mailto:willnode@wellosoft.net
Forum (for public discussions): https://forum.unity3d.com/threads/379305/

When asking support via email or chat, please include your invoice number along the message.

Historical code and documentation can be accessed in git repository, in case if you need it.
