﻿using System;
using static TexDrawLib.TexParserUtility;
namespace TexDrawLib
{
    public class RotateAtom : Atom
    {
        public override Box CreateBox(TexBoxingState state)
        {
            throw new NotImplementedException();
        }

        public override void Flush()
        {
            throw new NotImplementedException();
        }
    }
}